package com.mob.shop.demo.util;

/**
 * Created by weishj on 2017/12/20.
 */

public class Constant {
	public static final String WXAPPID = "wx6c033dfc1026e3cb";
}
